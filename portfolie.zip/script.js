/**
 * script.js — Pankaj Portfolio
 * Three.js hero, GSAP animations, chatbot, cursor, and more
 */

/* ════════════════════════════════════════════════════════
   REGISTER GSAP PLUGINS
════════════════════════════════════════════════════════ */
gsap.registerPlugin(ScrollTrigger, TextPlugin);

/* ════════════════════════════════════════════════════════
   LOADER
════════════════════════════════════════════════════════ */
(function initLoader() {
  const loader    = document.getElementById('loader');
  const loaderBar = document.getElementById('loaderBar');
  const loaderPct = document.getElementById('loaderPercent');
  let pct = 0;

  const interval = setInterval(() => {
    pct += Math.random() * 15;
    if (pct >= 100) {
      pct = 100;
      clearInterval(interval);
      setTimeout(hideLoader, 400);
    }
    loaderBar.style.width = pct + '%';
    loaderPct.textContent  = Math.floor(pct) + '%';
  }, 120);

  function hideLoader() {
    gsap.to(loader, {
      opacity: 0,
      scale: 1.05,
      duration: 0.8,
      ease: 'power2.inOut',
      onComplete: () => {
        loader.style.display = 'none';
        initSite();
      }
    });
  }
})();

/* ════════════════════════════════════════════════════════
   INIT SITE (after loader)
════════════════════════════════════════════════════════ */
function initSite() {
  initCursor();
  initNavbar();
  initHeroThree();
  initHeroTyping();
  initHeroCounters();
  initScrollAnimations();
  initSkillBars();
  initTimeline();
  initContactForm();
  initSoundToggle();

  // Hero entrance
  gsap.from('.hero-badge', { opacity: 0, y: 30, duration: 0.8, delay: 0.2, ease: 'power3.out' });
  gsap.from('.hero-name', { opacity: 0, y: 50, duration: 1, delay: 0.4, ease: 'power3.out' });
  gsap.from('.hero-typing-wrap', { opacity: 0, y: 20, duration: 0.7, delay: 0.8, ease: 'power3.out' });
  gsap.from('.hero-desc', { opacity: 0, y: 20, duration: 0.7, delay: 1.0, ease: 'power3.out' });
  gsap.from('.hero-cta-group', { opacity: 0, y: 20, duration: 0.7, delay: 1.2, ease: 'power3.out' });
  gsap.from('.hero-stats', { opacity: 0, y: 20, duration: 0.7, delay: 1.4, ease: 'power3.out' });
  gsap.from('.hero-scroll-hint', { opacity: 0, duration: 1, delay: 2, ease: 'power2.out' });
}

/* ════════════════════════════════════════════════════════
   CUSTOM CURSOR
════════════════════════════════════════════════════════ */
function initCursor() {
  const dot   = document.getElementById('cursorDot');
  const ring  = document.getElementById('cursorRing');
  const trail = document.getElementById('cursorTrail');
  const trailDots = [];
  const maxTrail  = 12;

  // Create trail dots
  for (let i = 0; i < maxTrail; i++) {
    const d = document.createElement('div');
    d.className = 'cursor-trail-dot';
    d.style.opacity = (1 - i / maxTrail) * 0.5;
    d.style.transform = `translate(-50%, -50%) scale(${1 - i * 0.07})`;
    trail.appendChild(d);
    trailDots.push({ el: d, x: 0, y: 0 });
  }

  let mx = 0, my = 0;
  let ringX = 0, ringY = 0;

  document.addEventListener('mousemove', (e) => {
    mx = e.clientX;
    my = e.clientY;

    gsap.set(dot, { x: mx, y: my });

    // Update trail
    trailDots.forEach((t, i) => {
      const prev = i === 0 ? { x: mx, y: my } : trailDots[i - 1];
      t.x += (prev.x - t.x) * 0.35;
      t.y += (prev.y - t.y) * 0.35;
      gsap.set(t.el, { x: t.x, y: t.y });
    });
  });

  // Smooth ring follow
  function animRing() {
    ringX += (mx - ringX) * 0.15;
    ringY += (my - ringY) * 0.15;
    gsap.set(ring, { x: ringX, y: ringY });
    requestAnimationFrame(animRing);
  }
  animRing();

  // Hover effect on interactive elements
  document.querySelectorAll('a, button, .project-card, .tech-icon, .chatbot-btn').forEach(el => {
    el.addEventListener('mouseenter', () => ring.classList.add('hover'));
    el.addEventListener('mouseleave', () => ring.classList.remove('hover'));
  });
}

/* ════════════════════════════════════════════════════════
   NAVBAR
════════════════════════════════════════════════════════ */
function initNavbar() {
  const navbar = document.getElementById('navbar');
  const toggle = document.getElementById('navToggle');
  const links  = document.getElementById('navLinks');

  window.addEventListener('scroll', () => {
    navbar.classList.toggle('scrolled', window.scrollY > 50);
  });

  toggle.addEventListener('click', () => {
    links.classList.toggle('open');
  });

  document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', () => links.classList.remove('open'));
  });
}

/* ════════════════════════════════════════════════════════
   THREE.JS HERO — PARTICLE FIELD + FLOATING TORUS
════════════════════════════════════════════════════════ */
function initHeroThree() {
  const canvas = document.getElementById('heroCanvas');
  const scene  = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(70, window.innerWidth / window.innerHeight, 0.1, 1000);
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });

  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setClearColor(0x000000, 0);

  camera.position.z = 30;

  // ── Particle field ────────────────────────────────
  const particleCount = 2500;
  const positions = new Float32Array(particleCount * 3);
  const colors    = new Float32Array(particleCount * 3);

  const c1 = new THREE.Color('#38bdf8');
  const c2 = new THREE.Color('#818cf8');
  const c3 = new THREE.Color('#34d399');

  for (let i = 0; i < particleCount; i++) {
    positions[i * 3]     = (Math.random() - 0.5) * 120;
    positions[i * 3 + 1] = (Math.random() - 0.5) * 80;
    positions[i * 3 + 2] = (Math.random() - 0.5) * 60;

    const pick = Math.random();
    const col  = pick < 0.5 ? c1 : pick < 0.8 ? c2 : c3;
    colors[i * 3]     = col.r;
    colors[i * 3 + 1] = col.g;
    colors[i * 3 + 2] = col.b;
  }

  const particleGeo = new THREE.BufferGeometry();
  particleGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  particleGeo.setAttribute('color', new THREE.BufferAttribute(colors, 3));

  const particleMat = new THREE.PointsMaterial({
    size: 0.18,
    vertexColors: true,
    transparent: true,
    opacity: 0.7,
    sizeAttenuation: true,
  });

  const particles = new THREE.Points(particleGeo, particleMat);
  scene.add(particles);

  // ── Floating geometric shapes ─────────────────────
  const objects = [];

  function addMesh(geometry, color, x, y, z) {
    const mat = new THREE.MeshBasicMaterial({
      color,
      wireframe: true,
      transparent: true,
      opacity: 0.25,
    });
    const mesh = new THREE.Mesh(geometry, mat);
    mesh.position.set(x, y, z);
    scene.add(mesh);
    objects.push(mesh);
    return mesh;
  }

  addMesh(new THREE.TorusGeometry(4, 1, 16, 40),  0x38bdf8, -15, 5, -10);
  addMesh(new THREE.IcosahedronGeometry(3, 0),     0x818cf8,  14, -4, -8);
  addMesh(new THREE.OctahedronGeometry(2.5, 0),    0x34d399,  0,  10, -5);
  addMesh(new THREE.TorusGeometry(2.5, 0.6, 8, 24), 0x38bdf8, 10, 8, -15);
  addMesh(new THREE.IcosahedronGeometry(2, 0),     0x818cf8, -12, -8, -12);

  // ── Grid plane ────────────────────────────────────
  const gridHelper = new THREE.GridHelper(100, 40, 0x38bdf8, 0x0f172a);
  gridHelper.position.y = -15;
  gridHelper.material.transparent = true;
  gridHelper.material.opacity = 0.15;
  scene.add(gridHelper);

  // ── Mouse parallax ────────────────────────────────
  let mouseX = 0, mouseY = 0;
  document.addEventListener('mousemove', (e) => {
    mouseX = (e.clientX / window.innerWidth - 0.5) * 2;
    mouseY = (e.clientY / window.innerHeight - 0.5) * 2;
  });

  // ── Animation loop ────────────────────────────────
  let frame = 0;
  function animate() {
    requestAnimationFrame(animate);
    frame++;

    const t = frame * 0.005;

    // Rotate particles slowly
    particles.rotation.y = t * 0.1;
    particles.rotation.x = t * 0.05;

    // Animate objects
    objects.forEach((obj, i) => {
      obj.rotation.x += 0.003 + i * 0.001;
      obj.rotation.y += 0.004 + i * 0.0015;
      obj.position.y += Math.sin(t + i) * 0.01;
    });

    // Camera mouse parallax
    camera.position.x += (mouseX * 3 - camera.position.x) * 0.03;
    camera.position.y += (-mouseY * 2 - camera.position.y) * 0.03;
    camera.lookAt(scene.position);

    renderer.render(scene, camera);
  }
  animate();

  // ── Resize handler ────────────────────────────────
  window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  });
}

/* ════════════════════════════════════════════════════════
   HERO TYPING EFFECT
════════════════════════════════════════════════════════ */
function initHeroTyping() {
  const el = document.getElementById('heroTyping');
  const phrases = [
    'I build IoT Systems',
    'I automate the future',
    'I create startups',
    'I ship ideas that matter',
  ];
  let pi = 0, ci = 0, deleting = false;

  function type() {
    const phrase = phrases[pi];
    if (!deleting) {
      el.textContent = phrase.slice(0, ci + 1);
      ci++;
      if (ci === phrase.length) {
        deleting = true;
        setTimeout(type, 2000);
        return;
      }
    } else {
      el.textContent = phrase.slice(0, ci - 1);
      ci--;
      if (ci === 0) {
        deleting = false;
        pi = (pi + 1) % phrases.length;
      }
    }
    setTimeout(type, deleting ? 50 : 90);
  }
  setTimeout(type, 1500);
}

/* ════════════════════════════════════════════════════════
   HERO STAT COUNTERS
════════════════════════════════════════════════════════ */
function initHeroCounters() {
  document.querySelectorAll('.stat-num').forEach(el => {
    const target = parseInt(el.dataset.target);
    gsap.to(el, {
      innerHTML: target,
      duration: 2,
      delay: 1.6,
      ease: 'power2.out',
      snap: { innerHTML: 1 },
    });
  });
}

/* ════════════════════════════════════════════════════════
   SCROLL ANIMATIONS (GSAP ScrollTrigger)
════════════════════════════════════════════════════════ */
function initScrollAnimations() {
  // ── Section headers ───────────────────────────────
  gsap.utils.toArray('.section-header').forEach(el => {
    gsap.from(el, {
      scrollTrigger: { trigger: el, start: 'top 85%', toggleActions: 'play none none none' },
      opacity: 0, y: 40, duration: 0.8, ease: 'power3.out',
    });
  });

  // ── About section ─────────────────────────────────
  gsap.from('.about-avatar-wrap', {
    scrollTrigger: { trigger: '#about', start: 'top 75%' },
    opacity: 0, x: -60, duration: 1, ease: 'power3.out',
  });
  gsap.from('.about-content', {
    scrollTrigger: { trigger: '#about', start: 'top 75%' },
    opacity: 0, x: 60, duration: 1, delay: 0.2, ease: 'power3.out',
  });

  // ── Skill categories ──────────────────────────────
  gsap.utils.toArray('.skill-category').forEach((el, i) => {
    gsap.from(el, {
      scrollTrigger: { trigger: '#skills', start: 'top 75%' },
      opacity: 0, y: 50, duration: 0.7, delay: i * 0.15, ease: 'power3.out',
    });
  });

  // ── Tech icons ────────────────────────────────────
  gsap.from('.tech-icon', {
    scrollTrigger: { trigger: '.tech-icons-cloud', start: 'top 85%' },
    opacity: 0, scale: 0.5, duration: 0.5,
    stagger: { amount: 0.8, from: 'random' },
    ease: 'back.out(1.7)',
  });

  // ── Project cards ─────────────────────────────────
  gsap.utils.toArray('.project-card').forEach((el, i) => {
    gsap.from(el, {
      scrollTrigger: { trigger: '#projects', start: 'top 75%' },
      opacity: 0, y: 60, duration: 0.8, delay: i * 0.2, ease: 'power3.out',
    });
  });

  // 3D tilt on project cards
  document.querySelectorAll('.project-card').forEach(card => {
    card.addEventListener('mousemove', (e) => {
      const rect = card.getBoundingClientRect();
      const cx   = rect.left + rect.width / 2;
      const cy   = rect.top  + rect.height / 2;
      const rx   = (e.clientY - cy) / (rect.height / 2) * -10;
      const ry   = (e.clientX - cx) / (rect.width / 2) * 10;
      gsap.to(card, {
        rotateX: rx, rotateY: ry,
        duration: 0.4, ease: 'power2.out',
        transformPerspective: 700,
      });
    });
    card.addEventListener('mouseleave', () => {
      gsap.to(card, { rotateX: 0, rotateY: 0, duration: 0.5, ease: 'power2.out' });
    });
  });

  // ── Contact section ───────────────────────────────
  gsap.from('.contact-info', {
    scrollTrigger: { trigger: '#contact', start: 'top 75%' },
    opacity: 0, x: -50, duration: 0.9, ease: 'power3.out',
  });
  gsap.from('.contact-form', {
    scrollTrigger: { trigger: '#contact', start: 'top 75%' },
    opacity: 0, x: 50, duration: 0.9, delay: 0.2, ease: 'power3.out',
  });

  // ── Footer ────────────────────────────────────────
  gsap.from('.footer-inner > *', {
    scrollTrigger: { trigger: '.footer', start: 'top 90%' },
    opacity: 0, y: 20, duration: 0.6,
    stagger: 0.1, ease: 'power2.out',
  });
}

/* ════════════════════════════════════════════════════════
   SKILL BARS
════════════════════════════════════════════════════════ */
function initSkillBars() {
  ScrollTrigger.create({
    trigger: '#skills',
    start: 'top 70%',
    onEnter: () => {
      document.querySelectorAll('.skill-bar-fill').forEach(bar => {
        const w = bar.dataset.width + '%';
        gsap.to(bar, { width: w, duration: 1.5, ease: 'power3.out' });
      });
    }
  });
}

/* ════════════════════════════════════════════════════════
   TIMELINE ITEMS
════════════════════════════════════════════════════════ */
function initTimeline() {
  const items = document.querySelectorAll('.timeline-item');
  const observer = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) e.target.classList.add('visible');
    });
  }, { threshold: 0.3 });
  items.forEach(item => observer.observe(item));
}

/* ════════════════════════════════════════════════════════
   CONTACT FORM
════════════════════════════════════════════════════════ */
function initContactForm() {
  const form    = document.getElementById('contactForm');
  const btnText = document.getElementById('btnText');
  const btnLoad = document.getElementById('btnLoader');
  const success = document.getElementById('formSuccess');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const name    = document.getElementById('formName').value;
    const email   = document.getElementById('formEmail').value;
    const message = document.getElementById('formMessage').value;

    btnText.style.display = 'none';
    btnLoad.style.display = 'flex';

    try {
      const res = await fetch('/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, message }),
      });
      const data = await res.json();

      btnText.style.display = 'flex';
      btnLoad.style.display = 'none';

      if (data.success) {
        success.classList.add('show');
        form.reset();
        playClickSound();
        setTimeout(() => success.classList.remove('show'), 5000);
      }
    } catch (err) {
      // Fallback for demo (no server)
      console.log('Demo mode — form data:', { name, email, message });
      btnText.style.display = 'flex';
      btnLoad.style.display = 'none';
      success.classList.add('show');
      form.reset();
      setTimeout(() => success.classList.remove('show'), 5000);
    }
  });
}

/* ════════════════════════════════════════════════════════
   PROJECT MODALS
════════════════════════════════════════════════════════ */
const modalData = {
  smartwaste: {
    icon: 'fas fa-trash-alt',
    title: 'Smart Waste Collector',
    category: 'IoT System',
    desc: 'An autonomous, sensor-driven waste management system built for smart cities. The system uses ultrasonic sensors to detect fill levels in bins, GPS for real-time tracking, and a Python-based ML model for optimal route generation. Data streams in real-time via MQTT to a central dashboard.',
    features: [
      'Ultrasonic sensors with HC-SR04 for bin fill detection',
      'GPS module for real-time bin location tracking',
      'MQTT broker for lightweight IoT messaging',
      'Python Flask dashboard for live monitoring',
      'ML-based route optimization for waste trucks',
      'SMS/WhatsApp alerts when bins exceed 80% capacity',
    ],
    tags: ['Arduino Uno', 'Raspberry Pi', 'Python', 'MQTT', 'GPS', 'Machine Learning', 'Flask', 'MySQL'],
  },
  whatsapp: {
    icon: 'fab fa-whatsapp',
    title: 'WhatsApp Automation Bot',
    category: 'Python Automation',
    desc: 'A comprehensive WhatsApp automation suite built with Python, capable of handling bulk messaging, auto-replies, group management, and custom command pipelines. The bot processes natural language inputs and executes intelligent responses using a rule-based decision engine.',
    features: [
      'Bulk scheduled message broadcasting to contacts/groups',
      'Keyword-triggered auto-reply engine',
      'Contact list management and segmentation',
      'Media file (image/PDF/audio) auto-forwarding',
      'Custom command pipeline for admin controls',
      'Web dashboard for bot management and logs',
    ],
    tags: ['Python', 'Selenium', 'Playwright', 'pywhatkit', 'REST API', 'SQLite', 'Flask'],
  },
  aiiot: {
    icon: 'fas fa-robot',
    title: 'NeuralEdge: AI + IoT Platform',
    category: 'Future Concept / In Development',
    desc: 'NeuralEdge is an ambitious next-generation platform that fuses Edge AI with IoT hardware to create self-learning, adaptive infrastructure nodes. Devices run TinyML models locally, eliminating cloud latency, while LoRaWAN provides long-range connectivity across entire city grids.',
    features: [
      'TensorFlow Lite models deployed on ESP32 & STM32 MCUs',
      'Edge inference for anomaly detection without cloud dependency',
      'LoRaWAN mesh network for city-scale deployment',
      'Federated learning for privacy-preserving model updates',
      'Digital twin visualization dashboard (Three.js)',
      'Predictive maintenance AI for industrial IoT systems',
    ],
    tags: ['TensorFlow Lite', 'ESP32', 'STM32', 'LoRaWAN', 'Edge AI', 'Python', 'Node.js', 'Three.js'],
  },
};

function openModal(key) {
  const d = modalData[key];
  if (!d) return;

  const content = document.getElementById('modalContent');
  content.innerHTML = `
    <div class="modal-project-icon"><i class="${d.icon}"></i></div>
    <div class="modal-category">${d.category.toUpperCase()}</div>
    <h2 class="modal-title">${d.title}</h2>
    <p class="modal-desc">${d.desc}</p>
    <div class="modal-features">
      <h4>// KEY FEATURES</h4>
      <ul>${d.features.map(f => `<li>${f}</li>`).join('')}</ul>
    </div>
    <div class="modal-tags">${d.tags.map(t => `<span class="ptag">${t}</span>`).join('')}</div>
  `;

  document.getElementById('modalOverlay').classList.add('active');
  document.body.style.overflow = 'hidden';
  playClickSound();
}

function closeModal() {
  document.getElementById('modalOverlay').classList.remove('active');
  document.body.style.overflow = '';
}

document.addEventListener('keydown', e => {
  if (e.key === 'Escape') closeModal();
});

/* ════════════════════════════════════════════════════════
   AI CHATBOT
════════════════════════════════════════════════════════ */
const botReplies = {
  'skills':    '⚡ Pankaj is skilled in Python, IoT (Arduino, ESP32, Raspberry Pi), Node.js, MQTT, WhatsApp automation, REST APIs, and more! He\'s also into Edge AI and TinyML.',
  'projects':  '💼 Key projects include: Smart Waste Collector (IoT), WhatsApp Automation Bot (Python), and NeuralEdge — an AI+IoT platform concept. Click "View Details" on any card to learn more!',
  'location':  '📍 Pankaj is based in India 🇮🇳 and available for remote collaborations worldwide!',
  'contact':   '📧 You can reach Pankaj at pankaj@example.com, or connect via GitHub/LinkedIn linked in the contact section!',
  'hackathons':'🏆 Pankaj has competed in SIH, TechFest IIT Bombay (1st Place!), HackMIT India, Hack the Future (2nd Place), and IBM\'s CodeForGood.',
  'iot':       '🔌 Pankaj specializes in IoT with hands-on experience in sensor integration, MQTT protocols, embedded systems, GPS tracking, and real-time dashboards.',
  'python':    '🐍 Python is Pankaj\'s primary language! He uses it for automation, IoT scripting, Flask APIs, ML models, and WhatsApp bots.',
  'startup':   '🚀 Pankaj is actively building toward becoming a tech entrepreneur — combining IoT + AI + automation into scalable startup ideas!',
  'hello':     '👋 Hey there! I\'m Pankaj\'s AI assistant. Ask me about his skills, projects, hackathons, or how to get in touch!',
  'hi':        '👋 Hi! Great to meet you. I can tell you about Pankaj\'s work, skills, or projects — what would you like to know?',
  'help':      '🤔 You can ask me about: skills, projects, IoT, Python, hackathons, startup, location, or how to contact Pankaj!',
};

function getReply(msg) {
  const m = msg.toLowerCase();
  for (const [key, reply] of Object.entries(botReplies)) {
    if (m.includes(key)) return reply;
  }
  return "🤖 Interesting question! I'm a simple bot — try asking about Pankaj's skills, projects, hackathons, or how to contact him!";
}

function toggleChat() {
  const win = document.getElementById('chatbotWindow');
  const btn = document.getElementById('chatbotBtn');
  win.classList.toggle('open');
  // Remove notification
  const notif = btn.querySelector('.chat-notif');
  if (notif) notif.style.display = 'none';
  playClickSound();
}

function sendChat() {
  const input = document.getElementById('chatInput');
  const msg = input.value.trim();
  if (!msg) return;

  addChatMsg(msg, 'user');
  input.value = '';

  setTimeout(() => {
    const reply = getReply(msg);
    addChatMsg(reply, 'bot');
  }, 600);

  playClickSound();
}

function sendSuggestion(btn) {
  const text = btn.textContent.replace(/^[^\s]+\s/, '').replace('?', '');
  document.getElementById('chatInput').value = text;
  sendChat();
  btn.style.opacity = '0.5';
}

function addChatMsg(text, type) {
  const messages = document.getElementById('chatMessages');
  const div = document.createElement('div');
  div.className = `chat-msg ${type === 'user' ? 'user-msg' : 'bot-msg'}`;
  div.innerHTML = `
    <div class="msg-avatar"><i class="fas fa-${type === 'user' ? 'user' : 'robot'}"></i></div>
    <div class="msg-bubble">${text}</div>
  `;
  messages.appendChild(div);
  messages.scrollTop = messages.scrollHeight;

  gsap.from(div, {
    opacity: 0, y: 10, duration: 0.3, ease: 'power2.out',
  });
}

/* ════════════════════════════════════════════════════════
   SOUND TOGGLE
════════════════════════════════════════════════════════ */
let soundEnabled = false;
const AudioCtx = window.AudioContext || window.webkitAudioContext;
let audioCtx = null;

function playClickSound() {
  if (!soundEnabled || !AudioCtx) return;
  if (!audioCtx) audioCtx = new AudioCtx();

  const osc  = audioCtx.createOscillator();
  const gain = audioCtx.createGain();

  osc.connect(gain);
  gain.connect(audioCtx.destination);

  osc.frequency.setValueAtTime(880, audioCtx.currentTime);
  osc.frequency.exponentialRampToValueAtTime(440, audioCtx.currentTime + 0.1);
  gain.gain.setValueAtTime(0.05, audioCtx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.15);

  osc.start(audioCtx.currentTime);
  osc.stop(audioCtx.currentTime + 0.15);
}

function initSoundToggle() {
  const btn  = document.getElementById('soundToggle');
  const icon = document.getElementById('soundIcon');

  btn.addEventListener('click', () => {
    soundEnabled = !soundEnabled;
    icon.className = soundEnabled ? 'fas fa-volume-high' : 'fas fa-volume-xmark';
    gsap.fromTo(btn, { scale: 0.85 }, { scale: 1, duration: 0.3, ease: 'back.out(1.7)' });
    if (!audioCtx && soundEnabled) audioCtx = new AudioCtx();
    playClickSound();
  });

  // Hover sounds
  document.querySelectorAll('.btn, .project-card, .tech-icon').forEach(el => {
    el.addEventListener('mouseenter', playClickSound);
  });
}

/* ════════════════════════════════════════════════════════
   SMOOTH SCROLL
════════════════════════════════════════════════════════ */
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', (e) => {
    e.preventDefault();
    const target = document.querySelector(a.getAttribute('href'));
    if (target) {
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
});

/* ════════════════════════════════════════════════════════
   GRID SCAN LINE (decorative)
════════════════════════════════════════════════════════ */
(function addScanLine() {
  const scan = document.createElement('div');
  scan.style.cssText = `
    position: fixed; left: 0; right: 0; height: 2px;
    background: linear-gradient(90deg, transparent, rgba(56,189,248,0.3), transparent);
    z-index: 99900; pointer-events: none; top: -2px;
  `;
  document.body.appendChild(scan);
  gsap.to(scan, {
    top: '100vh', duration: 4, ease: 'none', repeat: -1, delay: 3,
  });
})();

console.log('%c PANKAJ PORTFOLIO ', 'background:#38bdf8;color:#020617;font-size:20px;font-weight:900;padding:8px 20px;font-family:monospace;');
console.log('%c IoT Developer | Python Automation | Future Entrepreneur ', 'color:#38bdf8;font-size:12px;font-family:monospace;');
